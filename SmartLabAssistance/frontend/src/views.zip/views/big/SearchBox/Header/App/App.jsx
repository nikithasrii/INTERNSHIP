import React from "react";
// import './app.css'
// import Header from "../Header";
// import Search from './Search';
// import { useState } from "react";
function App() {
    // const [Mystate, update] = useState(
    //     {
    //         exp: true,
    //     })
    // const handleChange = (inputtext) => {
    //     update({ exp: inputtext.length === 0 ? true : false })
    // }
    return (
        <div>
            {/* <Header exp={Mystate.exp} />
            
            <Search handleChange={handleChange} /> */}
        </div>
    )
}
export default App; 